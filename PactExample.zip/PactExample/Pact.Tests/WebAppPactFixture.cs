﻿using System;
using Microsoft.Owin.Hosting;
using Pact.App_Start;

namespace Pact.Tests
{
    public class WebAppPactFixture : IDisposable
    {
        internal const string CollectionName = "Web API Pacts";
        internal const string ProviderName = "Web API";
        internal const string ServiceUri = "http://localhost:8000";
        private readonly IDisposable webAppDisposable;

        public WebAppPactFixture()
        {
            webAppDisposable = WebApp.Start<OwinStartup>(ServiceUri);
        }

        #region IDisposable Support

        private bool disposedValue; // To detect redundant calls

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    webAppDisposable.Dispose();
                }

                disposedValue = true;
            }
        }

        #endregion IDisposable Support
    }
}