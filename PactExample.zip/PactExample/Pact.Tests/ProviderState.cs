﻿namespace Pact.Tests
{
    public class ProviderState
    {
        public string Consumer { get; set; }
        public string State { get; set; }
    }
}