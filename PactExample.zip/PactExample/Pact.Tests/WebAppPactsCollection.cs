﻿using Xunit;

namespace Pact.Tests
{
    [CollectionDefinition(WebAppPactFixture.CollectionName)]
    public class WebAppPactsCollection : ICollectionFixture<WebAppPactFixture>
    {
    }
}