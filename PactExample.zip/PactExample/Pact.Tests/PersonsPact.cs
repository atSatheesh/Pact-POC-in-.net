﻿using System.Collections.Generic;
using PactNet;
using PactNet.Infrastructure.Outputters;
using Xunit;
using Xunit.Abstractions;

namespace Pact.Tests
{
    [Collection(WebAppPactFixture.CollectionName)]
    public class PersonsPact
    {
        private readonly WebAppPactFixture _fixture;
        private readonly ITestOutputHelper _output;

        public PersonsPact(WebAppPactFixture fixture, ITestOutputHelper output)
        {
            _fixture = fixture;
            _output = output;
        }

        [Fact]
        public void EnsurePersonsApiHonorsPactWithConsumer()
        {
            var config = new PactVerifierConfig
            {
                Outputters = new List<IOutput>
                {
                    new XUnitOutput(_output)
                }
            };

            var pactVerifier = new PactVerifier(config);

            pactVerifier
                .ServiceProvider(WebAppPactFixture.ProviderName, WebAppPactFixture.ServiceUri)
                .HonoursPactWith("Generic")
                .PactUri(".\\Pacts\\PersonsPact.json")
                .Verify();
        }
    }
}