﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Pact.Models;

namespace Pact.Controllers
{
    [RoutePrefix("persons")]
    public class PersonController : ApiController
    {
        private readonly List<Person> _persons = new List<Person>
        {
            new Person{ Id = 1, Name = "John Doe", Email="john.doe@example.com"},
            new Person{ Id = 2, Name = "Jane Doe", Email="jane.doe@example.com"}
        };

        // GET: Default
        [Route("")]
        public IHttpActionResult Get()
        {
            return Ok(_persons);
        }

        [Route("{id}", Name = "GetPersonById")]
        public IHttpActionResult Get(int id)
        {
            var person = _persons.FirstOrDefault(x => x.Id == id);

            if (person == null)
            {
                return NotFound();
            }

            return Ok(person);
        }
    }
}