﻿namespace Pact
{
    public class WebApiApplication : System.Web.HttpApplication
    {
    }
}