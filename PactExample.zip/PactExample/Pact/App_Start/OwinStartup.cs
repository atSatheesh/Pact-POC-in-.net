﻿using System.Net.Http.Formatting;
using System.Web.Http;
using Microsoft.Owin;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Owin;

[assembly: OwinStartup(typeof(Pact.App_Start.OwinStartup))]

namespace Pact.App_Start
{
    public class OwinStartup
    {
        public void Configuration(IAppBuilder app)
        {
            var httpConfig = new HttpConfiguration();

            httpConfig.SuppressHostPrincipal();

            //configure JSON settings
            httpConfig.Formatters.Clear();
            httpConfig.Formatters.Add(new JsonMediaTypeFormatter());
            httpConfig.Formatters.JsonFormatter.SerializerSettings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            };
            httpConfig.Formatters.JsonFormatter.SerializerSettings.Converters.Add(new StringEnumConverter());

            // Web API routes
            httpConfig.MapHttpAttributeRoutes();

#if DEBUG
            if (app.Properties.ContainsKey("host.AppMode"))
            {
                app.Properties["host.AppMode"] = "development";
            }
            else
            {
                app.Properties.Add("host.AppMode", "development");
            }
#endif

            app.UseErrorPage();
            app.UseWebApi(httpConfig);
        }
    }
}