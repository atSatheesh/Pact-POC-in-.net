﻿namespace Pact.Models
{
    public class Person
    {
        public string Email { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
    }
}